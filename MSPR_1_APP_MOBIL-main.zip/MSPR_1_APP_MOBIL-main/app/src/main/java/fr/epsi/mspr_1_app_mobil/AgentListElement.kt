package fr.epsi.mspr_1_app_mobil

class AgentListElement (val fullname: String, val agentUrl: String) {
}